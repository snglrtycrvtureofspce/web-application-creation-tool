document.addEventListener('DOMContentLoaded', function () {
    for (let i = 0; i < 10; i++) {
        var rr = Math.ceil((60 * Math.random()) + 5);
        var rx = Math.ceil(400 * Math.random());
        var ry = Math.ceil(10 * Math.random());
        document.getElementById("z2").innerHTML += '<div class="circle" style="width:' + rr + 'px;height:' + rr + 'px;left:' + rx + 'px;top:' + ry + 'px;background:#'+Math.floor(Math.random()*1677745).toString(16)
        +';"></div>';
    }
});
var count = -2;
var circles;
function ChangeColor(){
    if(count ==-2)
    {
    circles = [].slice.call(document.getElementsByClassName("circle"));
    count=circles.length;
    console.log(circles);
    }
    if(count>-1)
    {
        if(count==0){
            alert("Поздравляем, все шарики красные!");
        }
        circles[count-1].style.background = 'red';
        count--;
    }
}

function ReverseText() {
    document.getElementById("result").value = [...document.getElementById("text").value].reverse().join("")
}
